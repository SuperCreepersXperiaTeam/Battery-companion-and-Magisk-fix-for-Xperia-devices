package com.supercreepersxperiateam.battery;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class BatteryWidgetProvider extends AppWidgetProvider {
    private static final String LOG = "/data/local/tmp/xperia_battery_companion/battery_log.csv";
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }
    public static void refreshAll(Context context) {
        AppWidgetManager m = AppWidgetManager.getInstance(context);
        int[] ids = m.getAppWidgetIds(new ComponentName(context, BatteryWidgetProvider.class));
        for (int id : ids) updateOne(context, m, id);
    }
    private static void updateOne(Context c, AppWidgetManager m, int id) {
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.battery_widget);
        String dump = rootRead(); String[] rows = dump.trim().split("\\r?\\n");
        String pct = "—", status = "Esperando módulo", remaining = "Autonomía calculándose…";
        List<long[]> samples = new ArrayList<>();
        for (int i=1;i<rows.length;i++) {
            String[] a=rows[i].split(",");
            if(a.length<6) continue;
            try {
                int p=Integer.parseInt(a[1].trim()); long t=timestamp(a[0].trim());
                if (a[5].trim().equals("muestra") && t>0) samples.add(new long[]{t,p});
                pct=String.valueOf(p); status="Última lectura: "+a[0].trim();
            } catch(Exception ignored) { }
        }
        if(!samples.isEmpty()) {
            long[] last=samples.get(samples.size()-1); pct=String.valueOf(last[1]);
            if(samples.size()>=2) {
                long[] first=samples.get(0); long[] prev=last;
                for(int i=samples.size()-2;i>=0;i--) { if(samples.get(i)[1]>last[1]) { first=samples.get(i); break; } }
                double hours=(last[0]-first[0])/3600000.0; double drop=first[1]-last[1];
                if(hours>=0.5 && drop>=2) { long mins=Math.round((last[1]/(drop/hours))*60.0); remaining=mins/60+" h "+mins%60+" min aprox."; }
            }
        } else if(dump.isEmpty()) status="Concede root a la aplicación";
        v.setTextViewText(R.id.widget_percent, pct.equals("—")?"—%":pct+"%");
        v.setTextViewText(R.id.widget_remaining, remaining);
        v.setTextViewText(R.id.widget_status, status);
        Intent launch=new Intent(c,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,0,launch,PendingIntent.FLAG_UPDATE_CURRENT | (android.os.Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        v.setOnClickPendingIntent(R.id.widget_percent,pi); v.setOnClickPendingIntent(R.id.widget_status,pi); v.setOnClickPendingIntent(R.id.widget_brand,pi);
        m.updateAppWidget(id,v);
    }
    private static String rootRead() {
        StringBuilder b=new StringBuilder();
        try { Process p=Runtime.getRuntime().exec(new String[]{"su","-c","cat "+LOG+" 2>/dev/null"});
            BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream())); String l; while((l=r.readLine())!=null)b.append(l).append('\n'); p.waitFor();
        } catch(Exception ignored) {} return b.toString();
    }
    private static long timestamp(String s) {
        try { java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US); f.setTimeZone(java.util.TimeZone.getDefault()); return f.parse(s).getTime(); }
        catch(Exception e){return -1;}
    }
}
